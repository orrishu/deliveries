import React, {Component} from 'react'
import {getData} from 'common/services/apiService'
import AsyncRequest from 'common/utils/AsyncRequest'
import {translate} from 'react-polyglot'
import {inject, observer} from 'mobx-react'
import {observable, toJS} from 'mobx'
import {Jumbotron, Grid, Row, Col} from 'react-bootstrap'
import CSSModules from 'react-css-modules'
import styles from './deliveries.scss'

@translate()
@inject('translationsStore')
@CSSModules(styles)
@observer
export default class Deliveries extends Component {

  @observable request = {};

  componentWillMount() {
    console.log('deliveries component')
    //this.request = new AsyncRequest(getData(458411))  //Test...
  }

  render() {
    const {t} = this.props
    if (this.request.error) {
      return <div>Error</div>
    }

    if (this.request.loading) {
      return <div>Loading</div>
    }

    console.log(toJS(this.request))

    const {results} = this.request

    return (
      <div className="container theme-showcase">
        {/*
          results.map((item, index) =>
            <div key={index}>{item.Title} - {item.Publisher} - {item.TenderType}</div>
          )
        */}
        <Jumbotron>
          <h1>{t('deliveries.title')}</h1>
          <p>
            {t('code.test')}
          </p>
        </Jumbotron>
        <Grid styleName="show-grid">
          <Row className="show-grid">
            <Col xs={12} md={8}>
              <code>&lt;{'Col xs={12} md={8}'} /&gt;</code>
            </Col>
            <Col xs={6} md={4}>
              <code>&lt;{'Col xs={6} md={4}'} /&gt;</code>
            </Col>
          </Row>

          <Row className="show-grid">
            <Col xs={6} md={4}>
              <code>&lt;{'Col xs={6} md={4}'} /&gt;</code>
            </Col>
            <Col xs={6} md={4}>
              <code>&lt;{'Col xs={6} md={4}'} /&gt;</code>
            </Col>
            <Col xsHidden md={4}>
              <code>&lt;{'Col xsHidden md={4}'} /&gt;</code>
            </Col>
          </Row>

          <Row className="show-grid">
            <Col xs={6} xsOffset={6}>
              <code>&lt;{'Col xs={6} xsOffset={6}'} /&gt;</code>
            </Col>
          </Row>

          <Row className="show-grid">
            <Col md={6} mdPush={6}>
              <code>&lt;{'Col md={6} mdPush={6}'} /&gt;</code>
            </Col>
            <Col md={6} mdPull={6}>
              <code>&lt;{'Col md={6} mdPull={6}'} /&gt;</code>
            </Col>
          </Row>
        </Grid>
      </div>
    )
  }
}
