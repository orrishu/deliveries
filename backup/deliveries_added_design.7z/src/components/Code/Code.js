import React, {Component} from 'react'
import {Jumbotron, Grid, Row, Col, FormGroup, ControlLabel, FormControl, HelpBlock} from 'react-bootstrap'
import {translate} from 'react-polyglot'
import {inject} from 'mobx-react'
import CSSModules from 'react-css-modules'
import styles from './code.scss'

@translate()
@inject('translationsStore')
@CSSModules(styles)
export default class Code extends Component {

  state = {
    value: ''
  }

  componentWillMount = () => {
    console.log('code component')
  }

  getValidationState() {
    const length = this.state.value.length
    if (length > 10) return 'success'
    else if (length > 5) return 'warning'
    else if (length > 0) return 'error'
    return null
  }

  handleChange = (e) => {
    this.setState({ value: e.target.value })
  }

  render() {
    const {t} = this.props
    return (
      <div className="container theme-showcase">
        <Jumbotron>
          <h1>{t('code.title')}</h1>
          <p>
            {t('code.test')}
          </p>
        </Jumbotron>
        <form>
          <FormGroup
            controlId="formBasicText"
            validationState={this.getValidationState()}
          >
            <ControlLabel>Working example with validation</ControlLabel>
            <FormControl
              type="text"
              value={this.state.value}
              placeholder="Enter text"
              onChange={this.handleChange}
            />
            <FormControl.Feedback />
            <HelpBlock>Validation is based on string length.</HelpBlock>
          </FormGroup>
        </form>
      </div>
    )
  }
}
