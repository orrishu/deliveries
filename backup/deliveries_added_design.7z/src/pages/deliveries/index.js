export { default } from './DeliveriesPage'
