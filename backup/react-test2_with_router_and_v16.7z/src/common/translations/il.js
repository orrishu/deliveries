export default {
  page404: 'מצטערים, הקישור שגוי',
  loading: 'טוען...',
  AppTitle: 'מכרזים',
  loginPage: {  
    usernameLabel: 'שם משתמש',
    passwordLabel: 'סיסמה',
    loginBtnTitle: 'כניסה',
    loginError: 'פרטי ההזדהות שהזנת שגויים, אנא נסה שנית.'
  },
  nav: {
    test: 'טסט',
    search: 'חיפוש'
  }
}
