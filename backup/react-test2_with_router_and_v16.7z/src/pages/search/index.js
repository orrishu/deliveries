export { default } from './SearchPage'
