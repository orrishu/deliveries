export { default } from './Deliveries'
